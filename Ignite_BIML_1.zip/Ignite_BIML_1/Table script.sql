
USE [Ignite]
GO
IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[NAM\skasturi004].[Src_EMP]') AND type in (N'U'))

CREATE TABLE [NAM\skasturi004].[Src_EMP](
	[employeeID] [int] NULL,
	[employeeName] [varchar](20) NULL) 


Go
IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[NAM\skasturi004].[Dst_BIML_EMP]') AND type in (N'U'))

CREATE TABLE [NAM\skasturi004].[Dst_BIML_EMP](
	[employeeID] [int] NULL,
	[employeeName] [varchar](20) NULL
) ON [PRIMARY]

--This is for inserting records into Src_EMP table

INSERT INTO Src_EMP VALUES(101,'Dom')
INSERT INTO Src_EMP VALUES(102,'Toyong')
INSERT INTO Src_EMP VALUES(103,'Suresh')
INSERT INTO Src_EMP VALUES(104,'Santhosh')
INSERT INTO Src_EMP VALUES(105,'Prakash')
INSERT INTO Src_EMP VALUES(106,'Azeem')